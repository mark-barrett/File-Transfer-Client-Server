#ifndef AUDIT_LOG_H
#define AUDIT_LOG_H

int generateAuditLogs();

#endif
