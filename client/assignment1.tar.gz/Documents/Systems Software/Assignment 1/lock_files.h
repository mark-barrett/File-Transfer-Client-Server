#ifndef LOCKFILES_H_
#define LOCKFILES_H_

int lockFiles();

#endif
