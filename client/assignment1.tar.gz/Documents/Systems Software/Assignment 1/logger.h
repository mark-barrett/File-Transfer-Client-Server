#ifndef LOGGER_H_
#define LOGGER_H_

int recordLog(char log[]);

#endif
