# Code-Backup-and-Deployment-Daemon
A daemon written in C that will backup both developing and production folders, will track changes to them and deploy the changes.

Adding new line to test commits from Linux.
